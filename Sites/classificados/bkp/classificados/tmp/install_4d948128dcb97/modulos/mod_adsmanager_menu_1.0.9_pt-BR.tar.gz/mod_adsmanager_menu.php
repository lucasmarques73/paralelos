<?php
// no direct access
defined( '_VALID_MOS' ) or die( 'Restricted access' );

function mod_adsmanager_menu_categories($id, $level, &$children,$itemid,$current_list,$expand,$order,$displaynumads) {
	global $cur_template;
	if (@$children[$id]) {
		foreach ($children[$id] as $row) {
			 if ($level == 0)
			 {
			 ?>
				<tr align="left"><td>
			<?php
				$class="mainlevel";
			 }
			 else
			 {
				echo '<div style="padding-left: '.($level*4).'px"><img src="templates/'.$cur_template.'/images/indent'.$level.'.png" alt="" />';
				$class="sublevel";
			 }
			 $link = sefRelToAbs("index.php?option=com_adsmanager&page=show_category&catid=".$row->id."&text_search=&order=$order&expand=$expand&Itemid=$itemid");
			 if ($displaynumads == 1)
			 {
				echo '<a href="'.$link.'" class="'.$class.'" >'.$row->name.' ('.$row->num_ads.')</a>';	
			 }
			 else
			 {
				echo '<a href="'.$link.'" class="'.$class.'" >'.$row->name.'</a>';
			 }
			 if (@$current_list[count($current_list) - 1 -$level] == $row->id)
			 {
				mod_adsmanager_menu_categories($row->id, $level+1, $children,$itemid,$current_list,$expand,$order,$displaynumads);
			 }
			 if ($level == 0)
			 {
			 ?>
				</td></tr>
			 <?php
			 }
			 else
			 {
			 ?>
				</div>
			 <?php
			 }
		}
	}
}

function calc_nb_ads($id,&$children,$sqltype) {
	switch($sqltype)
	{
		case 1:
		{
		   $nb_ads = 0;
		   if (@$children[$id]) {   
			  $nb = count($children[$id]);
			  for($i=0;$i < $nb;$i++)
			  { 
				 $children[$id][$i]->num_ads += calc_nb_ads($children[$id][$i]->id,$children,$sqltype);
				 $nb_ads += $children[$id][$i]->num_ads;
			  }
		   }
		   return $nb_ads;
		} break;
		
		case 0:
		{
			$nb_ads = 0;
			if (@$children[$id]) {	
				$nb = count($children[$id]);
				for($i=0;$i < $nb;$i++)
				{
					if (!isset($children[$id][$i]->not_empty))
							$children[$id][$i]->num_ads = 0;
							
					$children[$id][$i]->num_ads += calc_nb_ads($children[$id][$i]->id,$children,$sqltype);
					if (isset($children[$id][$i]->not_empty))
						$nb_ads += $children[$id][$i]->num_ads;
				}
			}
			return $nb_ads;
		} break;
	}
}

/****************************************************/
$itemid = intval( mosGetParam( $_GET, 'Itemid', 0 ));
$catid = intval( mosGetParam( $_GET, 'catid', -1 ));
$expand = intval( mosGetParam( $_GET, 'expand', 0 ));
$order = intval( mosGetParam( $_GET, 'order', 0 ));
$displaynumads = $params->def('displaynumads',1);
$sqltype = $params->def('sqltype',0);

switch ($sqltype)
{
	case 1:
		$database->setQuery("SELECT c.*, ".
				" (SELECT count(*) ".
				"  FROM #__adsmanager_ads a ".
				"  LEFT JOIN #__adsmanager_adcat as adcat ON adcat.adid = a.id ".
				"  WHERE adcat.catid = c.id ".
				"    AND a.published = 1 ".
				" ) as num_ads ".
				"FROM #__adsmanager_categories as c ".
				"WHERE c.published = 1 ".
				"ORDER BY c.parent,c.ordering");
		break;
	case 0:
	default:
	
		$database->setQuery( "SELECT c.*, count(*) as num_ads,a.id as not_empty ".
					 "FROM #__adsmanager_ads as a ".
					 "LEFT JOIN #__adsmanager_adcat as adcat ON a.id = adcat.adid ".
					 "RIGHT JOIN #__adsmanager_categories as c ON adcat.catid = c.id ".
					 "WHERE c.published = 1 ".
					 "GROUP BY c.id ".
					 "ORDER BY c.parent,c.ordering");
		break;
}
						 
$rows = $database->loadObjectList();
if ($database -> getErrorNum()) {
	echo $database -> stderr();
	return false;
}
			 
// establish the hierarchy of the menu
$children = array();
$orderlist = array();
// first pass - collect children
foreach ($rows as $v ) {
	$pt 	= $v->parent;
	$list 	= @$children[$pt] ? $children[$pt] : array();
	array_push( $list, $v );
	$children[$pt] = $list;
	$orderlist[$v->id] = $v;
}

if ($displaynumads == 1)
	$nb_ads = calc_nb_ads(0,$children,$sqltype);

$current_list[] = $catid;
if ($catid != -1)
{
	$current = $catid;
	while((isset($orderlist[$current])) && ($orderlist[$current]->parent != 0))
	{
			$current_list[] = $orderlist[$current]->parent;
			$current = $orderlist[$current]->parent;
	}
}

if (file_exists($mosConfig_absolute_path .'/components/com_adsmanager/lang/lang_' . $mosConfig_lang . '.php'))
	include_once( $mosConfig_absolute_path .'/components/com_adsmanager/lang/lang_' . $mosConfig_lang . '.php' );
else
	include_once( $mosConfig_absolute_path .'/components/com_adsmanager/lang/lang_english.php' );
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<?php
$link_front = sefRelToAbs("index.php?option=com_adsmanager&Itemid=$itemid");
$link_write_ad = sefRelToAbs("index.php?option=com_adsmanager&page=write_ad&Itemid=$itemid");
$link_show_profile = sefRelToAbs("index.php?option=com_adsmanager&page=show_profile&Itemid=$itemid");
$link_show_user = sefRelToAbs("index.php?option=com_adsmanager&amp;page=show_user&amp;Itemid=$itemid");
			
$link_show_rules = sefRelToAbs("index.php?option=com_adsmanager&page=show_rules&Itemid=$itemid");
$link_show_all = sefRelToAbs("index.php?option=com_adsmanager&page=show_all&text_search=&order=$order&expand=$expand&Itemid=$itemid");
?>
<?php
if ($displaynumads == 1)
	$all = ADSMANAGER_MENU_ALL_ADS. "($nb_ads)";
else
	$all = ADSMANAGER_MENU_ALL_ADS;
?>
<tr align="left"><td><a href="<?php echo $link_show_all; ?>" class="mainlevel"><?php echo $all;?> </a></td></tr>
<tr align="left"><td><span class="mainlevel" >- - - - - - -</span></td></tr>
<?php
mod_adsmanager_menu_categories(0, 0, $children,$itemid,$current_list,$expand,$order,$displaynumads);
?>
</table>
