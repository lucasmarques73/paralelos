<?php
// no direct access
defined( '_VALID_MOS' ) or die( 'Restricted access' );

function selectCategories($id, $level, $children,$catid) {
	if (@$children[$id]) {
		foreach ($children[$id] as $row) {
			?>
			<option value="<?php echo $row->id; ?>" <?php if ($catid == $row->id) echo "selected='selected'"; ?>><?php echo $level.$row->name; ?></option>
			<?php 
			selectCategories($row->id, $level." >> ",$children,$catid);
		}
	}
}

function getAdsManagerLangDefinition($text) {
		if(defined($text)) $returnText = constant($text); 
		else $returnText = $text;
		return $returnText;
	}


/****************************************************/
$catid = intval( mosGetParam( $_GET, 'catid', -1 ));
$text_search = mosGetParam($_GET,'text_search','');
$itemid = intval($params->get( 'default_itemid', mosGetParam( $_GET, 'Itemid', 0 ) )) ;
$advanced_search = intval($params->get( 'advanced_search', 1)) ;
$search_by_cat = intval($params->get( 'search_by_cat', 1)) ;
$fields[] = $params->get( 'field1', "") ;
$fields[] = $params->get( 'field2', "") ;
$fields[] = $params->get( 'field3', "") ;
$fields[] = $params->get( 'field4', "") ;
$fields[] = $params->get( 'field5', "") ;
$type = $params->get( 'type', "table") ;
$listfields="";
foreach($fields as $field)
{
	if (($listfields == "")&&($field != ""))
		$listfields .= "'$field'";
	if ($field != "")
		$listfields .= ",'$field'";
}
if ($listfields != "")
{
	$query = "SELECT f.* FROM #__adsmanager_fields AS f ".
						 "WHERE f.name IN ($listfields) AND f.published = 1 ORDER by f.ordering" ;
	$database->setQuery( $query);
	//echo $query;
	$fields_searchable = $database->loadObjectList("name");
	if ($database->getErrorNum()) {
		echo $database->stderr();
		return;
	}

	//get value fields
	$database->setQuery( "SELECT * FROM #__adsmanager_field_values ORDER by ordering ");
	$fieldvalues = $database->loadObjectList();
	if ($database -> getErrorNum()) {
		echo $database -> stderr();
		return false;
	}

	$field_values = array();
	// first pass - collect children
	if (isset($fieldvalues))
	{
		foreach ($fieldvalues as $v ) {
			$pt 	= $v->fieldid;
			$list 	= @$field_values[$pt] ? $field_values[$pt] : array();
			array_push( $list, $v );
			$field_values[$pt] = $list;
		}
	}
	
	foreach($fields_searchable as $field)
	{
		if ($field->cbfieldvalues != "-1")
		{
			/*get CB value fields */
			$database->setQuery( "SELECT *, fieldtitle as fieldvalue FROM #__comprofiler_field_values WHERE fieldid = $field->cbfieldvalues ORDER by ordering ");
			$cbfieldvalues = $database->loadObjectList();
			if ($database -> getErrorNum()) {
				echo $database -> stderr();
				return false;
			}
			$field_values[$field->fieldid] = $cbfieldvalues;
		}
	}
}

$database->setQuery( "SELECT c.* FROM #__adsmanager_categories as c ".
						 "WHERE c.published = 1 ORDER BY c.parent,c.ordering");
						 
$rows = $database->loadObjectList();
if ($database -> getErrorNum()) {
	echo $database -> stderr();
	return false;
}
					 
// establish the hierarchy of the menu
$children = array();
// first pass - collect children
foreach ($rows as $v ) {
	$pt 	= $v->parent;
	$list 	= @$children[$pt] ? $children[$pt] : array();
	array_push( $list, $v );
	$children[$pt] = $list;
}

if (file_exists($mosConfig_absolute_path .'/components/com_adsmanager/lang/lang_' . $mosConfig_lang . '.php'))
	include_once( $mosConfig_absolute_path .'/components/com_adsmanager/lang/lang_' . $mosConfig_lang . '.php' );
else
	include_once( $mosConfig_absolute_path .'/components/com_adsmanager/lang/lang_english.php' );

$url = "index.php";
?>
<form action="<?php echo $url; ?>" method="get">
<input type="hidden" name="option" value="com_adsmanager" />
<input type="hidden" name="Itemid" value="<?php echo $itemid; ?>" />
<input type="hidden" name="page" value="search" />
<input class="inputbox" type="text" name="text_search" value="<?php echo $text_search; ?>" onblur="if(this.value=='') this.value='<?php echo $text_search; ?>';" onfocus="if(this.value=='<?php echo $text_search; ?>') this.value='';"/><br/>
<?php if ($search_by_cat == 1)
{
?>
	<div class='mod_adsmanager_search_cats'><select class="inputbox" name="catid" id="category">
	<option value="0" <?php if ($catid == -1) echo "selected='selected'"; ?>><?php echo ADSMANAGER_MENU_ALL_ADS; ?></option>
	<?php selectCategories(0,"",$children,$catid); ?>
	</select></div>
<?php
}
if (isset($fields_searchable)) {
if ($type == "table")
	echo "<table width='100%' border='0'>";
foreach($fields_searchable as $fsearch) {
	if (($catid == 0)||(strpos($fsearch->catsid, ",$catid,") !== false)||(strpos($fsearch->catsid, ",-1,") !== false))
	{
		$currentvalue = mosGetParam( $_GET, $fsearch->name, "" );
		if ($type == "table")
			echo "<tr><td>";
		else
			echo "<div class='mod_adsmanager_search_field'>";
			
		if (($fsearch->display_title & 2) == 2)
		{
			//echo getAdsManagerLangDefinition($fsearch->title);
			if ($type == "div")
				echo "&nbsp;";
		}
		else if ($type == "table")
			echo "&nbsp;";
			
		if ($type == "table")
			echo "</td><td>";
			
		switch($fsearch->type)
		{
			case 'checkbox':
				echo "<input class='inputbox' type='checkbox' name='$fsearch->title' value='1' />\n";
				break;
			case 'multicheckbox':
				echo "<table class='cbMulti'>\n";
				$k = 0;
				for ($i=0 ; $i < $fsearch->rows;$i++)
				{
					echo "<tr>\n";
					for ($j=0 ; $j < $fsearch->cols;$j++)
					{
						$fieldvalue = @$field_values[$fsearch->fieldid][$k]->fieldvalue;
						$fieldtitle = @$field_values[$fsearch->fieldid][$k]->fieldtitle;
						if (isset($fieldtitle))
							$fieldtitle=getAdsManagerLangDefinition($fieldtitle);
						echo "<td>\n";
						if (isset($field_values[$fsearch->fieldid][$k]->fieldtitle))
						{		
							echo "<input class='inputbox' type='checkbox' name='".$fsearch->name."[]' value='$fieldvalue' />&nbsp;$fieldtitle&nbsp;\n";
						}
						echo "</td>\n";
						$k++;
					}
					echo "</tr>\n";
				}
				echo "</table>\n";
				break;

			case 'radio':
			case 'select':
				echo "<select id='".$fsearch->name."' name='".$fsearch->name."'>\n";
				echo "<option value='' >".sprintf(ADSMANAGER_SEARCH_SELECT,getAdsManagerLangDefinition($fsearch->title))."</option>\n";	
				if (isset($field_values[$fsearch->fieldid])) {
				foreach($field_values[$fsearch->fieldid] as $v)
				{
					$ftitle = getAdsManagerLangDefinition($v->fieldtitle);
					if ($currentvalue == "$v->fieldvalue")
						echo "<option value='$v->fieldvalue' selected='selected'>$ftitle</option>\n";
					else
						echo "<option value='$v->fieldvalue' >$ftitle</option>\n";
				}
				}
				
				echo "</select>\n";
				break;
			
			case 'multiselect':
			
				echo "<select name=\"".$fsearch->name."[]\" multiple='multiple' size='$fsearch->size'>\n";	
				if (isset($field_values[$fsearch->fieldid])) {
				foreach($field_values[$fsearch->fieldid] as $v)
				{
					$ftitle = getAdsManagerLangDefinition($v->fieldtitle);
					if ($field->required == 1)
						$mosReq = "mosReq='1'";
						
					echo "<option value='$v->fieldvalue' >$ftitle</option>\n";
				}
				}
				
				echo "</select>\n";
				break;
			
			case 'price':
				echo "<select id='".$fsearch->name."' name='".$fsearch->name."'>\n";
				echo "<option value='' >".sprintf(ADSMANAGER_SEARCH_SELECT,getAdsManagerLangDefinition($fsearch->title))."</option>\n";	
				if (isset($field_values[$fsearch->fieldid])) {
				foreach($field_values[$fsearch->fieldid] as $v)
				{
					$ftitle = getAdsManagerLangDefinition($v->fieldtitle);
					if ($currentvalue == "$v->fieldvalue")
						echo "<option value='$v->fieldvalue' selected='selected'>$ftitle</option>\n";
					else
						echo "<option value='$v->fieldvalue' >$ftitle</option>\n";
				}
				}
				
				echo "</select>\n";
				break;
							
			case 'textarea':
			case 'number':
			case 'emailaddress':
			case 'url':
			case 'text':
				echo "<input name='".$fsearch->name."' id='".$fsearch->name."' maxlength='20' class='inputbox' type='text' size='20' />";
				break;
		}
		if ($type == "table")
			echo "</td></tr>";
		else
			echo "</div>";
	}
}
if ($type == "table")
	echo "</table>";
}?>

<input type="submit" class="button" value="<?php echo ADSMANAGER_SEARCH_TITLE; ?>"/>
</form>
<?php if ($advanced_search == 1)
{
?>
<div><a href="<?php echo sefRelToAbs("index.php?option=com_adsmanager&amp;page=show_search&amp;catid=$catid&amp;Itemid=$itemid");?>"><?php echo ADSMANAGER_ADVANCED_SEARCH; ?></a></div>
<?php
}
?>