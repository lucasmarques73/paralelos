tinyMCE.addI18n('en.browser_dlg',{
delta_width : 0,
delta_height : 0				
});