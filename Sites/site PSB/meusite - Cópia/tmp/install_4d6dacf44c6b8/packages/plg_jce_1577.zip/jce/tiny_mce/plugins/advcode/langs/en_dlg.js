tinyMCE.addI18n('en.advcode_dlg',{
title:"Advanced Code Editor",
wordwrap:"Word Wrap",
highlight:"Highlight",
language:"Language",
numbers:"Line Numbers",
autocomplete:"AutoComplete",
'fontsize':"Font Size",
strong: 'Bold',
em: 'Italic',
underline: 'Underline',
removeformat: 'Remove Format',
format: 'Format',
undo: 'Undo',
redo: 'Redo'
});