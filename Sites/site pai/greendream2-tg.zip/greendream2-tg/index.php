<?php
/**
 * @copyright	Copyright (C) 2005 - 2007 Open Source Matters. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */
defined( '_JEXEC' ) or die( 'Restricted access' );
$tg = 0;
if ($this->countModules('left') == 0 && $this->countModules('right') == 0 ) { $tg = 1; }
if ($this->countModules('left') && $this->countModules('right') == 0) { $tg = 2; }
if ($this->countModules('left') == 0 && $this->countModules('right')) { $tg = 3; }
if ($this->countModules('left') && $this->countModules('right')) { $tg = 4; }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>">
<head><jdoc:include type="head" />
<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/system/css/system.css" type="text/css" />
<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/system/css/general.css" type="text/css" />
<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template?>/css/style.css" type="text/css" />
<?php if ($this->countModules('hornav')): ?>
<script language="javascript" type="text/javascript" src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template?>/js/moomenu.js"></script>
<?php endif; ?>
<!--[if lte IE 6]>
<style>
#hornav ul li ul {
left: -999em;
margin-top: 0px;
margin-left: 0px;
}
.tg-top, .tg-bottom, .tg  {  behavior: url("templates/TEMPLATENAME/css/fix.htc"); }
</style>
<![endif]-->
</head>
<body>
<div id="tg-top" class="tg-top"></div>
<div id="tg" class="tg">
<div id="template-top">
		<div class="template-top-">
		<div id="logo"></div>
		</div>
		<div class="template-top">
		
			<div id="template-top-second"><jdoc:include type="modules" name="user4" style="xhtml" /></div>
		</div>
</div>
<div id="template-menu"><div id="hornav"><jdoc:include type="modules" name="user3" style="xhtml" /></div></div>

<div id="template">
	<div id="template-center<?php echo $tg ?>">
		<?php if ($this->countModules('left')) { ?><div id="allsidebar-left"><jdoc:include type="modules" name="left" style="tg" /></div><?php } ?>	
		<div id="template-center-center<?php echo $tg ?>">
		<div id="template-center-center-center<?php echo $tg ?>"><jdoc:include type="component" />
		<div id="tg-advert1"><jdoc:include type="modules" name="tg-advert1" /></div><?php include "html/mod_mostread/component.php"; ?>		
		</div>
		</div>		
		<?php if ($this->countModules('right')) { ?><div id="allsidebar-right"><jdoc:include type="modules" name="right" style="tg" /></div><?php } ?>	
		<div style="clear: both;"></div></div>
</div>	
<?php if ($this->countModules('tg-user3') || $this->countModules('tg-user4')) { ?>
<div id="tg-user-bottom" class="clearfix">
	<div class="tg-user3"><jdoc:include type="modules" name="tg-user3" style="xhtml" /></div>
	<div class="tg-user4"><jdoc:include type="modules" name="tg-user4" style="xhtml" /></div>
</div>
<?php } ?>
<div id="tg-bottom-menu" class="clearfix">
<div id="tg-bottom-menu-left"><div id="credit" class="credit">Designed by <a href="http://www.themegoat.com" target="_blank">Education Joomla template</a></div></div>
<div id="tg-bottom-menu-right"></div>
</div>
</div>
<div id="tg-bottom" class="tg-bottom"></div>

</body>
</html>