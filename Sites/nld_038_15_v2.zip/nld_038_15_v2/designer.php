<?php

$width = $_GET['width'];
$font_s = $_GET['font_s'];
$font_color = $_GET['font_color'];
$domain = $_SERVER['SERVER_NAME'];

if(isset($width))
{
	$_SESSION['width'] = $width;
	setcookie ('width', $width, time()+31536000, '/', false);
	
	if ($width=='narrow'){
		setcookie ('users_resolution', '800', time()+31536000, '/', false);
	} else {
		setcookie ('users_resolution', '1024', time()+31536000, '/', false);
	}
	
}

if(isset($font_s))
{
	$_SESSION['font_s'] = $font_s;
	setcookie ('font_s', $font_s, time()+31536000, '/', false);
}
if(isset($font_color))
{
	$_SESSION['font_color'] = $font_color;
	setcookie ('font_color', $font_color, time()+31536000, '/', false);
}
header("Location: " . $_SERVER['HTTP_REFERER']);

?>