<?php
$screen_res = '1024';
if(isset($_COOKIE["users_resolution"]))
$screen_res = $_COOKIE["users_resolution"];
else 
{
?>
<script language="javascript" type="text/javascript">
<!--
createCookie('users_resolution',screen.width);
function createCookie(name,value) {
  
  var date = new Date();
  date.setTime(date.getTime()+(2*60*60*1000));
  var expires = "; expires="+date.toGMTString();
 
  
  document.cookie = name+"="+value+expires+"; path=/";
};
location = location.href;
//-->
</script>
<?php
}
?> 


<?php

$font_s = "default";
$font_color = "default";

$width = "narrow";

//load font style
if (isset($_SESSION['font_s'])) {
	$font_s = $_SESSION['font_s'];
} elseif (isset($_COOKIE['font_s'])) {
	$font_s = $_COOKIE['font_s'];
}
//load font style
if (isset($_SESSION['font_color'])) {
	$font_color = $_SESSION['font_color'];
} elseif (isset($_COOKIE['font_color'])) {
	$font_color = $_COOKIE['font_color'];
}

//load width style
if (isset($_SESSION['width'])) {
	$width = $_SESSION['width'];
} elseif (isset($_COOKIE['width'])) {
	$width = $_COOKIE['width'];
}


if ((int)$screen_res>=801){
	$width = "wide";
} else {
	$width = "narrow";
}



?>