<?php
/**
 * @copyright	Copyright (C) 2005 - 2007 Open Source Matters. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

include_once (dirname(__FILE__).DS.'/designer_load.php');

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" >
<head>
<jdoc:include type="head" />
 
<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/system/css/system.css" type="text/css" />
<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/system/css/general.css" type="text/css" />

<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/<?php echo $this->params->get('backgroundVariation'); ?>.css" type="text/css" />
<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/<?php echo $this->params->get('colorVariation'); ?>.css" type="text/css" />
<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/template_<?php echo $font_color;?>.css" type="text/css" />


<script language="javascript" type="text/javascript" src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/stchanger.js"></script>
<script language="javascript" type="text/javascript" src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/js/cssmenus.js"></script>


 
</head>

<body class="<?php echo $font_s; ?>; color_<?php echo $this->params->get('colorVariation'); ?>; bg_<?php echo $this->params->get('backgroundVariation'); ?>">
	


			<table border="0" cellpadding="0" cellspacing="0" align="center" width="1200px">
			<tr>
			<td valign="top" >
				<table border="0" cellpadding="0" cellspacing="0" align="left" id="header">
				<tr>
				<td valign="top">
					<table border="0" cellpadding="0" cellspacing="0" align="left" >
					<tr>
					<td id="sitename" valign="top" >
					<div id="sitename_com"></div>
					</td>
					<td valign="top" >
						<table border="0" cellpadding="0" cellspacing="0" align="left" id="table_header_right">
						<tr>
						<td valign="top" >
							<table border="0" cellpadding="0" cellspacing="0" align="right">
							<tr>
							<td valign="top" >
								<table cellpadding="0" cellspacing="0" border="0" align="right" id="designer">
								<tr>
								<td valign="top">

									<table cellpadding="0" cellspacing="0" border="0" id="colors" align="right">
									<tr>
									
									<td valign="top" id="colors_def1"><a href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/designer.php?font_color=default" title="default color"><div id="default1"><img src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/images/des_def.png" onMouseover="this.src='<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/images/des_def_hover.png'" onMouseout="this.src='<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/images/des_def.png'" border="0" height="16" width="16"></div></a></td>
									<td valign="top" id="colors_def2"><a href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/designer.php?font_color=white" title="white color"><div id="default2"><img src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/images/des_whi.png" onMouseover="this.src='<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/images/des_whi_hover.png'" onMouseout="this.src='<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/images/des_whi.png'" border="0" height="16" width="16"></div></a></td>
									<td valign="top" id="colors_def3"><a href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/designer.php?font_color=blue" title="blue color"><div id="default3"><img src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/images/des_blu.png" onMouseover="this.src='<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/images/des_blu_hover.png'" onMouseout="this.src='<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/images/des_blu.png'" border="0" height="16" width="16"></div></a></td>
									<td valign="top" id="colors_def4"><a href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/designer.php?font_color=orange" title="orange color"><div id="default4"><img src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/images/des_ora.png" onMouseover="this.src='<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/images/des_ora_hover.png'" onMouseout="this.src='<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/images/des_ora.png'" border="0" height="16" width="16"></div></a></td>
									<td valign="top" id="colors_def5"><a href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/designer.php?font_color=red" title="red color"><div id="default5"><img src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/images/des_red.png" onMouseover="this.src='<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/images/des_red_hover.png'" onMouseout="this.src='<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/images/des_red.png'" border="0" height="16" width="16"></div></a></td>
									<td valign="top"><span class="desi3"><a href="index.php" title="size +"onclick="changeFontSize(1);return false;">A+</a></span></td>
									<td valign="top"><span class="desi4"><a href="index.php" title="size -"onclick="changeFontSize(-1);return false;">A-</a></span></td>
									<td valign="top"><span class="desi5"><a href="index.php" title="reset size"onclick="revertStyles(); return false;">Re</a></span></td>
									</tr>
									</table>
							
								</td>
								</tr>
								</table>
							</td>
							</tr>
							</table>
						
					
						</td>
						</tr>
						<tr>
						<td valign="top" >
							<table border="0" cellpadding="0" cellspacing="0" >
							<tr>
							<td id="user3" valign="top"><jdoc:include type="modules" name="user3" style="xhtml" /></td>
							<td  valign="top">
								<table border="0" cellpadding="0" cellspacing="0" id="menu_top">
								<tr>
								<td  valign="top">	</td>
								</tr>
								</table>
							</td>
							</tr>
							</table>
						</td>
						</tr>
						</table>
					</td>
					</tr>
					</table>
		
					
				</td>	
				</tr>
				<tr>
				<td id="pathway" valign="top" ><span class="desi1"><jdoc:include type="module" name="breadcrumbs" /></span>
				</td>
				</tr>
				</table>
			
			</td>
			</tr>
			
			<tr>
			<td valign="top" >
				<table border="0" cellpadding="0" cellspacing="0" align="left" id="content">
				<tr>
				<?php if($this->countModules('left')) : ?>
				<td valign="top" id="left">
					<table border="0" cellpadding="0" cellspacing="0" align="left">
					<tr>
					<td id="left_top"><div id="search"><jdoc:include type="modules" name="user4" style="xhtml" /></div></td>
					</tr>
					<tr>
					<td valign="top" id="left_inner"><jdoc:include type="modules" name="left" style="xhtml" /></td>
					</td>
					</tr>
					<tr>
					<td id="left_bottom">&nbsp;</td>
					</tr>
					</table>
				</td>	
				<?php endif; ?>
				<td valign="top">
					<table border="0" cellpadding="0" cellspacing="0" align="left" id="body_com">
					<?php if($this->countModules('top')) : ?><tr>
					<td valign="top" id="body_outer_top">	
						<table border="0" cellpadding="0" cellspacing="0" align="left">
						<tr>
						<td valign="top" id="news1"><jdoc:include type="modules" name="top" style="xhtml" />
						</td>
						<?php if($this->countModules('user1')) : ?><td valign="top" id="news2"><span class="desi2"><jdoc:include type="modules" name="user1" style="xhtml" /></span>
						</td><?php endif; ?>
						</tr>
						</table>	
					</td>
					</tr><?php endif; ?>
					<tr>
					<td valign="top">
							<table border="0" cellpadding="0" cellspacing="0" align="left"  id="body_outer">
							<tr>
							<td valign="top">		
							<jdoc:include type="component" /><br /><br />
							<div align="center"><jdoc:include type="modules" name="footer" style="xhtml"/></div>
							</td>
							
							</tr>
							</table>
					</td>
					</tr>
					<tr>
					<td valign="top" id="body_outer_bottom">	
						<table border="0" cellpadding="0" cellspacing="0" align="center">
						<tr>
						<td valign="top" id="copy">

			Design by <a href="http://www.next-level-design.de" target="_blank">Next Level Design</a> / Script by <a href="http://www.joomla.org" target="_blank">Joomla!</a> 
		
			<!--Do not remove Designlink!Den Designlink nicht entfernen!-->	</td>
						</tr>
						</table>	
					</td>
					</tr>
					</table>
				</td>
				
				</tr>	
				</table>
			</td>
			</tr>
			<tr>
			<td>
	
					<table border="0" cellpadding="0" cellspacing="0" align="left" id="content_bottom">
					<tr>
					<td>
					</td>
					</tr>
					</table>
				</td>
				
				</tr>	
				</table>
			
			
	
				
<br />
<jdoc:include type="module" name="debug" style="-1" />
</body>
</html>
