/*
  Name: Pesquisa Sequencial
  Copyright: 
  Author: Henrique Garcia Campos
  Date: 05/07/11 17:31
  Description: Programa que executa pesquisa sequencial em vetores.
*/

#include <stdio.h>
#include <stdlib.h>


int gera_aleatorio(int MAX){
     return rand()%MAX;
}

int *aloca_vetor (int tamanha_vetor){
    int *v;        /* ponteiro para o vetor */
    if (tamanha_vetor < 1) {  /* verifica parametros recebidos */
       printf ("** Nao e possivel alocar vetor sem posicoes **\n");
       return (NULL);
    }
    /* aloca o vetor */
    v =  calloc (tamanha_vetor, sizeof(int));
    if (v == NULL) {
       printf ("** Erro: Memoria Insuficiente **");
       return (NULL);
    }
    return (v);    /* retorna o ponteiro para o vetor */
}

void preenche_vetor(int *vetor, int tamanha_vetor){
       int i;
       srand(time(NULL));
       for(i=0;i<tamanha_vetor;i++)
           vetor[i] = gera_aleatorio(tamanha_vetor*tamanha_vetor);
}

int pesquisa(int *vetor, int chave, int tamanha_vetor){
     int i;
     for(i=0;i<tamanha_vetor;i++){
                                  if(vetor[i] == chave)
                                              return i;
     }
     return -1;
}

void imprime_vetor(int *vetor, int start, int end){
       int i;
       for(i=start;i<end;i++)
           printf("%d ",vetor[i]);
}

int main(){
    int tamanha_vetor = 15;// modifique o tamanho do vetor para outras bases de testes.
    int *vetor = aloca_vetor(tamanha_vetor);
    int chave,opcao;
    int resultado,flag;
    preenche_vetor(vetor,tamanha_vetor);
    do{
       system("cls");
       printf("1: Imprime vetor;\n2: Pesquisa Vetor;\n");
       scanf("%d", &opcao);
       switch(opcao){
                  case 1:
                       system("cls");
                       imprime_vetor(vetor,0,tamanha_vetor);
                       printf("\n\n");
                       break;
                  case 2:
                       system("cls");
                       printf("Digite o numero que vc deseja procurar no vetor: ");
                       scanf("%d", &chave);
                       resultado = pesquisa(vetor,chave,tamanha_vetor);
                       if(resultado == -1)
                                    printf("Sua pesquisa nao foi bem sucedida.\n");
                       else
                           printf("Objeto encontrado posicao: %d\n\n", resultado);
                       break;
                  default:
                          break;                  
       }
       printf("Deseja continuar:\n 1:sim;\n 2:nao\n");
       scanf("%d", &flag);
    }while(flag == 1);
    system("pause");
    return 0;   
}
