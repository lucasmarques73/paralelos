/*
  Name: Desliga PC
  Author: Henrique Garcia Campos
  Date: 12/07/11 22:54
  Description: Programa simples para desligar seu computador, podendo programar o tempo.
*/


#include <stdio.h>
#include <stdlib.h>

int main(){
    int cont=0;
    while(!(system("shutdown -s -t 30")) ){ // o numero 30 significa o tempo necessario,em segundos, para desligar o computador.
                             cont++;
                             printf("%d ", cont);                         
    }
    return 0;
}
