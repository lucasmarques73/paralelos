<?php /**
 * @copyright	Copyright (C) 2005 - 2007 Open Source Matters. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 ----------------------------------------------------------------------------------
 * Free Professional Template by JoomlAxe.com
 * Author Spy2furious@gmail.com
 * This template is GNU GPL Licence
 * For Other Free Professional Template Please Visit JoomlAxe.com
 */

defined( '_JEXEC' ) or die( 'Restricted access' );
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb">
<head>
<jdoc:include type="head" />
<link rel="stylesheet" href="templates/_system/css/general.css" type="text/css" />
<link rel="stylesheet" href="templates/<?php echo $this->template ?>/css/template.css" type="text/css" />
<link rel="stylesheet" href="templates/<?php echo $this->template ?>/css/joomla_css.css" type="text/css" />
<link rel="stylesheet" href="templates/<?php echo $this->template ?>/css/suffix.css" type="text/css" />
<link rel="stylesheet" href="templates/<?php echo $this->template ?>/css/typo.css" type="text/css" />
<?php if($this->countModules('right or search') <= 0) :?>
<link rel="stylesheet" href="templates/<?php echo $this->template ?>/css/collapse.css" type="text/css" />
<?php endif; ?> 
</head>
<body>
<!-- Header /-->

<div class="header">
	<div class="headergradation">
		<div class="container">
			<div class="logo">
				<a href="index.php" title="Axe Industrial - Home">
					<img src="templates/<?php echo $this->template ?>/images/logo.png" alt="Axe Industrial" title="Axe Industrial" />
				</a>
			</div>
			<?php if($this->countModules('top')) :?>
			<div id="topmenu"><jdoc:include type="modules" name="top" style="XHTML" /></div>
			<?php endif; ?> 
		</div>
	</div>
</div>
<!-- Underheader /-->

<div class="underheader">
	<?php if($this->countModules('user1 or user2 or user3 or user4')) :?>
	<div class="container">
		<div class="underheader1"><jdoc:include type="modules" name="user1" style="XHTML" /></div>
		<div class="underheader2"><jdoc:include type="modules" name="user2" style="XHTML" /></div>
		<div class="underheader3"><jdoc:include type="modules" name="user3" style="XHTML" /></div>
		<div class="underheader4"><jdoc:include type="modules" name="user4" style="XHTML" /></div>
	</div>
	<?php endif; ?> 
</div>

<!-- Mainbody /-->
<div class="containermainbody"> 
	<div class="container">
		<div class="leftcolumn">
			<div id="pathway"><jdoc:include type="module" name="breadcrumbs" /></div>
			<div class="messagecontainer"><jdoc:include type="message" /></div>
			<div class="mainbody"><jdoc:include type="component" /></div>
		</div>
		<?php if($this->countModules('right or search')) :?>
		<div class="rightcolumn">
			<div class="searchcontainer"><jdoc:include type="modules" name="search" style="XHTML" /></div>
			<div class="rightcontainer"><jdoc:include type="modules" name="right" style="XHTML" /></div>
		</div>
		<?php endif; ?> 
	</div>
</div>
<!-- Banner /-->

<div class="containerbanner">
	<?php if($this->countModules('user5')) :?>
	<div class="container"><jdoc:include type="modules" name="user5" style="XHTML" /></div>
	<?php endif; ?>
</div>

<!-- Underbanner /-->
<?php if($this->countModules('user6 or user7 or user8')) :?>
<div class="underbanner">
	<div class="container">
		<div class="underbanner1"><jdoc:include type="modules" name="user6" style="XHTML" /></div>
		<div class="underbanner2"><jdoc:include type="modules" name="user7" style="XHTML" /></div>
		<div class="underbanner3"><jdoc:include type="modules" name="user8" style="XHTML" /></div>
	</div>
</div>
<?php endif; ?> 
<!-- 	We request you retain the full copyright notice below including the link to www.joomlaxe.com.
		This not only gives respect to the large amount of time given freely by the developers
		but also helps build interest, traffic and use of Joomlaxe Template. If you (honestly) cannot retain
		the full copyright we ask you at least leave in place the "Designed By JoomlAxe" line, with
		"JoomlAxe" linked to www.joomlaxe.com.
		-= Regards, Spy2furious, JoomlAxe Developer =-
/-->
<div class="footer">
	<div class="footergradation">
		<div class="container">
			<div class="copyright">
				Copyright &copy; 2008 Axe Industrial - 1st October 08 JoomlAxe Template. 
				Designed by <a href="http://www.joomlaxe.com">JoomlAxe.com</a><br />
				XHTML and CSS valid
			</div>
		</div>
	</div>
</div>
</body>
</html>








