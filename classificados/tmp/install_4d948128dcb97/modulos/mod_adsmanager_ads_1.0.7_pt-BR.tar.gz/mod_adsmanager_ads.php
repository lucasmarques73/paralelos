<?php
// no direct access
defined( '_VALID_MOS' ) or die( 'Restricted access' );

if (!function_exists("recurseSearch"))
	{
		function recurseSearch($rows,&$list,$catid){
			if(isset($rows))
			{
				foreach($rows as $row) {
					if ($row->parent == $catid)
					{
						$list[]= $row->id;
						recurseSearch($rows,$list,$row->id);
					} 
				}
			}
		}
	}
	
if (!defined( '_MOS_ADSMANAGER_MODULE' )) {
	/** ensure that functions are declared only once */
	define( '_MOS_ADSMANAGER_MODULE', 1 );
	
	function reorderDate( $date ){
		return mosFormatDate($date);
	}
	
	function moduleIsNewAd($date,$nbdays) {
		if ( $date && ereg( "([0-9]{4})-([0-9]{2})-([0-9]{2})", $date, $regs ) ) {
			if (defined('ADSMANAGER_DATE_FORMAT_LC'))
				$format = ADSMANAGER_DATE_FORMAT_LC;
			else
				$format = _DATE_FORMAT_LC;
			
			$date = mktime( 0, 0, 0, $regs[2], $regs[3], $regs[1] );
			$limitdate = mktime()-($nbdays*24*3600);
			if ($date >= $limitdate )
				return true;
			else
				return false;
		}
		else
			return false;
	}
	
	function displayVerticalLatestAds($ads,$image,$itemid,$conf,$displaycategory,$displaydate)
	{
		global $mosConfig_absolute_path,$mosConfig_live_site;
		
		$nb_images = $conf->nb_images;
		
		if ($image == 1)
		{
	?>
			<ul class="adsmanager_ver_list">
			<?php
			if(isset($ads[0])) {
			foreach($ads as $row) {
			?>
				<li>
				<?php	
				$linkTarget = sefRelToAbs("index.php?option=com_adsmanager&amp;page=show_ad&amp;adid=".$row->id."&Itemid=".$itemid);			
				$ok = 0;$i=1;
				while(!$ok)
				{
					if ($i < $nb_images + 1)
					{
						$ext_name = chr(ord('a')+$i-1);
						$pic = $mosConfig_absolute_path."/images/com_adsmanager/ads/".$row->id.$ext_name."_t.jpg";
						if (file_exists( $pic)) 
						{
							echo "<div align='center'><a href='".$linkTarget."'><img src='".$mosConfig_live_site."/images/com_adsmanager/ads/".$row->id.$ext_name."_t.jpg' alt='".htmlspecialchars(stripslashes($row->ad_headline),ENT_QUOTES)."' border='0' /></a>";
							$ok = 1;
						}
					}
					else
					{
						echo "<div align='center'><a href='".$linkTarget."'><img src='".$mosConfig_live_site."/components/com_adsmanager/images/nopic.gif' alt='noimage' border='0' /></a>"; 
						$ok = 1;
					}   
					$i++;   	
				}
				echo "<br /><a href='$linkTarget'>".stripslashes($row->ad_headline)."</a>"; 
				$iconflag = false;
				if (($conf->show_new == true)&&(moduleIsNewAd($row->date_created,$conf->nbdays_new))) {
					echo "<div align='center'><img align='center' src='".$mosConfig_live_site."/components/com_adsmanager/images/new.gif' /> ";
					$iconflag = true;
				}
				if (($conf->show_hot == true)&&($row->views >= $conf->nbhits)) {
					if ($iconflag == false)
						echo "<div align='center'>";
					echo "<img align='center' src='".$mosConfig_live_site."/components/com_adsmanager/images/hot.gif' />";
					$iconflag = true;
				}
				if ($iconflag == true)
					echo "</div>";
					
				if ($displaycategory == 1)
				{
					if ($iconflag == false)
						echo "<br />";
					echo "<span class=\"adsmanager_cat\">(".$row->parent." / ".$row->cat.")</span>";
				}
				if ($displaydate == 1)
				{
					if (($iconflag == false)||($displaycategory == 1))
						echo "<br />";
					echo reorderDate($row->date_created);
					$iconflag = true;
				}
				echo "</div>";
				?>
				</li>
		<?php
			} }
			?>
			</ul>
			<?php
		}
		else
		{
			?>
			<ul class="mostread">
			<?php
			if (isset($ads[0])){
			foreach($ads as $row) {
			?>
				<li class="mostread">
				<?php	
					$linkTarget = sefRelToAbs("index.php?option=com_adsmanager&amp;page=show_ad&amp;adid=".$row->id."&amp;catid=".$row->category."&amp;Itemid=".$itemid);
					echo "<a href='$linkTarget'>".stripslashes($row->ad_headline)."</a>";
					if ($displaycategory == 1)
						echo "&nbsp;<span class=\"adsmanager_cat\">(".$row->parent." / ".$row->cat.")";
					if ($displaydate == 1)
						echo "&nbsp;".reorderDate($row->date_created)."</span>"; 
				?>
				</li>
		<?php
			}}
			?>
			</ul>
			<?php
		}	
	}
	
	function displayHorizontalLatestAds($ads,$image,$itemid,$conf,$displaycategory,$displaydate)
	{
		global $mosConfig_absolute_path,$mosConfig_live_site;
		
		$nb_images = $conf->nb_images;
		
		if ($image == 1)
		{
		?>
			<div class='adsmanager_box_module_2'>
			<table class='adsmanager_inner_box_2' width="100%">
			<tr align="center">
			<?php
			$ads_by_row = 4;
			$num_ads = 0;
			if (isset($ads[0])) {
			foreach($ads as $row) {
				if ($num_ads >= $ads_by_row) {
					echo "</tr><tr>";
					$num_ads = 0;
				}
				?>
				<td>
				<?php	
				$linkTarget = sefRelToAbs("index.php?option=com_adsmanager&amp;page=show_ad&amp;adid=".$row->id."&amp;Itemid=".$itemid);			
				$ok = 0;$i=1;
				while(!$ok)
				{
					if ($i < $nb_images + 1)
					{
						$ext_name = chr(ord('a')+$i-1);
						$pic = $mosConfig_absolute_path."/images/com_adsmanager/ads/".$row->id.$ext_name."_t.jpg";
						if (file_exists( $pic)) 
						{
							echo "<div align='center'><a href='".$linkTarget."'><img src='".$mosConfig_live_site."/images/com_adsmanager/ads/".$row->id.$ext_name."_t.jpg' alt='".htmlspecialchars(stripslashes($row->ad_headline),ENT_QUOTES)."' border='0' /></a>";
							$ok = 1;
						}
					}
					else
					{
						echo "<div align='center'><a href='".$linkTarget."'><img src='".$mosConfig_live_site."/components/com_adsmanager/images/nopic.gif' alt='noimage' border='0' /></a>"; 
						$ok = 1;
					}   
					$i++;   	
				}
					
				echo "<br /><a href='$linkTarget'>".stripslashes($row->ad_headline)."</a>"; 
				$iconflag = false;
				if (($conf->show_new == true)&&(moduleIsNewAd($row->date_created,$conf->nbdays_new))) {
					echo "<div align='center'><img align='center' src='".$mosConfig_live_site."/components/com_adsmanager/images/new.gif' /> ";
					$iconflag = true;
				}
				if (($conf->show_hot == true)&&($row->views >= $conf->nbhits)) {
					if ($iconflag == false)
						echo "<div align='center'>";
					echo "<img align='center' src='".$mosConfig_live_site."/components/com_adsmanager/images/hot.gif' />";
					$iconflag = true;
				}
				if ($iconflag == true)
					echo "</div>";
					
				if ($displaycategory == 1)
				{
					if ($iconflag == false)
						echo "<br />";
					echo "<span class=\"adsmanager_cat\">(".$row->parent." / ".$row->cat.")</span>";
				}
				if ($displaydate == 1)
				{
					if (($iconflag == false)||($displaycategory == 1))
						echo "<br />";
					echo reorderDate($row->date_created);
					$iconflag = true;
				}
				echo "</div>";
				?>
				</td>
			<?php
				$num_ads ++;
			} }
			for(;$num_ads < $ads_by_row;$num_ads++)
			{
				echo "<td></td>";
			}
			?>
			</tr>
			</table>
			</div>
		<?php
		}
		else
		{
			?>
			<ul class="mostread">
			<?php
			if (isset($ads[0])) {
			foreach($ads as $row) {
			?>
				<li class="mostread">
				<?php	
					$linkTarget = sefRelToAbs("index.php?option=com_adsmanager&amp;page=show_ad&amp;adid=".$row->id."&amp;catid=".$row->category."&amp;Itemid=".$itemid);
					echo "<a href='$linkTarget'>".stripslashes($row->ad_headline)."</a>"; 
					if ($displaycategory == 1)
						echo "<br /><span class=\"adsmanager_cat\">(".$row->parent." / ".$row->cat.")</span>";
					if ($displaydate == 1)
						echo "<br />".reorderDate($row->date_created);
				?>
				</li>
		<?php
			} }
			?>
			</ul>
			<?php
		}
	}
	
	//$mainframe->addCustomHeadTag('<link rel="stylesheet" href="'.$mosConfig_live_site.'/components/com_adsmanager/css/adsmanager.css" type="text/css" />');
	?>
	<link rel="stylesheet" href="<?php echo $mosConfig_live_site; ?>/components/com_adsmanager/css/adsmanager.css" type="text/css" />
	<?php
}

if (file_exists($mosConfig_absolute_path .'/components/com_adsmanager/lang/lang_' . $mosConfig_lang . '.php'))
	require_once( $mosConfig_absolute_path .'/components/com_adsmanager/lang/lang_' . $mosConfig_lang . '.php' );
else
	require_once( $mosConfig_absolute_path .'/components/com_adsmanager/lang/lang_english.php' );
	
$nb_ads = intval($params->get( 'nb_ads', 3 )) ;
$image = intval($params->get( 'image', 1 )) ;
$itemid = intval($params->get( 'default_itemid', mosGetParam( $_GET, 'Itemid', 0 ) )) ;
$sort_sql = intval($params->get( 'random',0));

$catselect = $params->get('catselect',"no");
$displaycategory = intval($params->get( 'displaycategory',1));
$displaydate = intval($params->get( 'displaydate',1));

switch($sort_sql)
{
	/* Popular */
	case 2:
		$order_sql = "ORDER BY a.views DESC,a.date_created DESC ,a.id DESC ";
		break;
		
	/* Random */
	case 1:
		$order_sql = "ORDER BY RAND() ";
		break;
		
	/* Latest */
	case 0: 
	default:
		$order_sql = "ORDER BY a.date_created DESC ,a.id DESC ";
		break;
}

$cat_query = "";
switch($catselect)
{
	case "no";
		break;
	
	case "-1":
		$catid = intval(mosGetParam( $_GET, 'catid', 0 ));
		$database->setQuery( "SELECT c.id, c.name,c.parent ".
						 " FROM #__adsmanager_categories as c ".
						 " WHERE c.published = 1 ORDER BY c.parent,c.ordering");			 
		$listcats = $database->loadObjectList();
		//List	
		$list = array();
		$list[] = $catid;
		recurseSearch($listcats,$list,$catid);
		$listids = implode(',', $list);
		if (($catid != 0)&&($catid != -1))
		{
			$cat_query = "adcat.catid IN ($listids) AND ";
		}
		break;
	default:
		$cat_query = "adcat.catid = $catselect AND ";
		break;
}

$database->setQuery("SELECT a.id,a.views, a.ad_headline, a.category, a.date_created,p.id as parentid,p.name as parent,c.id as catid, c.name as cat ".
					"FROM #__adsmanager_ads as a ".
					"LEFT JOIN #__adsmanager_adcat as adcat ON adcat.adid = a.id ".
					"LEFT JOIN #__users as u ON a.userid = u.id ".
					"LEFT JOIN #__adsmanager_categories as c ON adcat.catid = c.id ".
					"LEFT JOIN #__adsmanager_categories as p ON c.parent = p.id ".
					"WHERE $cat_query c.published = 1 and a.published = 1 GROUP BY a.id $order_sql LIMIT 0, $nb_ads");
					
$ads = $database->loadObjectList();

// get configuration
$database->setQuery( "SELECT * FROM #__adsmanager_config");
$database->loadObject($conf);
if ($database -> getErrorNum()) {
	echo $database -> stderr();
	return false;
}

if ( file_exists( $mosConfig_absolute_path . "/components/com_paidsystem/api.paidsystem.php")) 
{
	require_once($mosConfig_absolute_path . "/components/com_paidsystem/api.paidsystem.php");
}

if (function_exists("getMaxPaidSystemImages"))
{
	$conf->nb_images += getMaxPaidSystemImages();
}

switch ( $params->get( 'style', 'hor' ) ) {
	case 'ver':
		displayVerticalLatestAds($ads,$image,$itemid,$conf,$displaycategory,$displaydate);
		break;
	
	case 'hor':
	default:
		displayHorizontalLatestAds($ads,$image,$itemid,$conf,$displaycategory,$displaydate);
		break;
}
?>