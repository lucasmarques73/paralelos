<?php
/**
* Field Plug for AdsManager
* Author: Thomas PAPIN
* URL:  http://www.joomprod.com
* mail: webmaster@joomprod.com
**/

class AdsManagerYouTubePlugin {

	function getListDisplay($contentid,$field)
	{
		return AdsManagerYouTubePlugin::getDetailsDisplay($contentid,$field);
	}

	function getDetailsDisplay($contentid,$field)
	{
		global $database;
		$query = "SELECT `key` FROM #__adsmanager_youtube ".
				 "WHERE fieldid = $field->fieldid AND contentid = $contentid";
		$fieldid = $field->fieldid;
		$database->setQuery($query);
		$value = $database->loadResult();
		$return ="";
		
		if ($value != "")
		{
			ereg( ".+v=(.+)$", $value, $regs );
			$key = $regs[1];
			$database->setQuery("SELECT * FROM #__adsmanager_youtube_conf WHERE fieldid = $field->fieldid");
			$database->loadObject($conf);
			 $return = '<object width="'.$conf->width.'" height="'.$conf->height.'">';
			 $return .=	'<param name="movie" value="http://www.youtube.com/v/'.$key.'&hl=fr&fs=1"></param>';
			 $return .=	'<param name="allowFullScreen" value="true"></param>';
			 $return .=	'<param name="allowscriptaccess" value="always"></param>';
			 $return .=	'<embed src="http://www.youtube.com/v/'.$key.'&hl=fr&fs=1" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="'.$conf->width.'" height="'.$conf->height.'">';
			 $return .=	'</embed>';
			$return .=	'</object>';
		}
		return $return;
	}

	function getFormDisplay($contentid,$field)
	{
		global $database;
		$query = "SELECT `key` FROM #__adsmanager_youtube ".
				 "WHERE fieldid = $field->fieldid AND contentid = $contentid";
		$fieldid = $field->fieldid;
		$database->setQuery($query);
		$value = $database->loadResult();
		
        $return = '<input type="text" size="30" name="youtube_key'.$fieldid.'" value="'.$value.'" />';
		$return .= '&nbsp;Enter Youtube URL';
		return $return;
	}

	function onFormSave($contentid,$fieldid,$update)
	{
		global $database;
		$url = mosGetParam($_POST,"youtube_key$fieldid",0);
		$key = $url;
		if ($update == 1)
		{
			$query = "DELETE FROM #__adsmanager_youtube WHERE fieldid = $fieldid AND contentid = $contentid";
			$database->setQuery($query);
			$database->query();
			$query = "INSERT INTO #__adsmanager_youtube (`fieldid`,`contentid`,`key`) VALUES ".
				 "($fieldid,$contentid,'$key')";	 
			$database->setQuery($query);
			$database->query();
		}
		else
		{
			$query = "INSERT INTO #__adsmanager_youtube (`fieldid`,`contentid`,`key`) VALUES ".
				 "($fieldid,$contentid,'$url')";	 
			$database->setQuery($query);
			$database->query();
		}
	}
	
	function onDelete($directory,$contentid = -1)
	{
		global $database;
		if ($contentid == -1)
			$query = "DELETE FROM #__adsmanager_youtube ".
					"WHERE 1";
		else
			$query = "DELETE FROM #__adsmanager_youtube ".
					"WHERE contentid = $contentid";
		$database->setQuery($query);
		$database->query();
	}
	
	function getEditFieldJavaScriptDisable()
	{
		$return = "elem=getObject('divYouTubeOptions');";
        $return .= "elem.style.visibility = 'hidden';";
		$return .= "elem.style.display = 'none';";
		$return .= "elem=getObject('youtube_width');";
		$return .= "elem.setAttribute('mosReq',0);";
		$return .= "elem=getObject('youtube_height');";
		$return .= "elem.setAttribute('mosReq',0);";
		return $return;
	}
	
	function getEditFieldJavaScriptActive()
	{
        $return = "disableAll();";
		$return .= "elem=getObject('divYouTubeOptions');";
        $return .= "elem.style.visibility = 'visible';";
        $return .= "elem.style.display = 'block';";
		$return .= "elem=getObject('youtube_width');";
		$return .= "elem.setAttribute('mosReq',1);";
		$return .= "elem=getObject('youtube_height');";
		$return .= "elem.setAttribute('mosReq',1);";
		return $return;
	}

	function getEditFieldOptions($fieldid)
	{
		global $database;
		$database->setQuery("SELECT * FROM #__adsmanager_youtube_conf WHERE fieldid = '$fieldid'");
		$database->loadObject($row);
		
		$return = "<div id='divYouTubeOptions'>";
		$return .= "<table class='adminform'>";
		$return .= "<tr>";
		$return .= "<td width='20%'>Player Width</td>";
		$return .= "<td width='20%' align=left><input type='text' id='youtube_width' name='youtube_width' mosReq=1 mosLabel='Player Width' class='inputbox' value='".@$row->width."' /></td>";
		$return .= "<td>&nbsp;</td>";
		$return .= "</tr>";
		$return .= "<tr>";
		$return .= "<td width='20%'>Player Height</td>";
		$return .= "<td width='20%' align=left><input type='text' id='youtube_height' name='youtube_height' mosReq=1 mosLabel='Player Height' class='inputbox' value='".@$row->height."' /></td>";
		$return .= "<td>&nbsp;</td>";
		$return .= "</tr>";
		$return .= "</table>";
		$return .= "</div>";
		return $return;
	}

	function saveFieldOptions($fieldid)
	{
		global $database;
		$width = mosGetParam($_POST,"youtube_width",0);
		$height = mosGetParam($_POST,"youtube_height",0);
		$database->setQuery("DELETE FROM #__adsmanager_youtube_conf WHERE fieldid = '$fieldid'");
		$database->query();
		$database->setQuery("INSERT INTO #__adsmanager_youtube_conf VALUES ($fieldid,$width,$height)");
		$database->query();
		return;
	}
	
	function getFieldName()
	{
		return "YouTube Player";
	}
	
	function install()
	{
		global $database;
		
		$query = "CREATE TABLE IF NOT EXISTS `#__adsmanager_youtube` ( ".
			  "`id` int(10) unsigned NOT NULL auto_increment, ".
			  "`fieldid` int(10) unsigned default NULL, ".
			  "`contentid` int(10) unsigned default NULL, ".
			  "`key` TEXT default NULL, ".
			  "PRIMARY KEY  (`id`) ".
			  "); ";
		$database->setQuery($query);
		$database->query();
		
		$query = "CREATE TABLE IF NOT EXISTS `#__adsmanager_youtube_conf` ( ".
			  "`fieldid` int(10) unsigned default NULL, ".
			  "`width` int(10) unsigned default '500', ".
			  "`height` int(10) unsigned default '300', ".
			  "PRIMARY KEY  (`fieldid`) ".
			  "); ";
		$database->setQuery($query);
		$database->query();
	}
	
	function uninstall()
	{
		global $database;
		
		$query = "DROP TABLE `#__adsmanager_youtube`";
		$database->setQuery($query);
		$database->query();
		
		$query = "DROP TABLE `#__adsmanager_youtube_conf`";
		$database->setQuery($query);
		$database->query();
	}
}

$plugins["youtube"] = new AdsManagerYouTubePlugin();
?>